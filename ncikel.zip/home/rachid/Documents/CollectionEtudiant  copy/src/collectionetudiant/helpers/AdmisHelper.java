
package collectionetudiant.helpers;

import collectionetudiant.models.*;

public class AdmisHelper {
    public static void getAdmis() throws Exception {


       
        String query = "SELECT AVG(valeur) FROM notes;";

        Db_Instance2.instance(query);
    }

}
